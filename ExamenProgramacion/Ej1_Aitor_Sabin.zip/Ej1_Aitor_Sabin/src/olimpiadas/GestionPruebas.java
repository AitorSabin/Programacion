package olimpiadas;

import java.util.ArrayList;
import atletas.Atleta;

public interface GestionPruebas {
	
	public void distribuirAtletas(ArrayList<Atleta> atletas);
	
}
